A LITTLE LOVE TEST — YOUR WEBSITE

Files:
- index.html: complete website (HTML + CSS + JavaScript in one file)

CUSTOMIZE:
1. Open index.html in a code editor.
2. Change the questions in the `questions` array near the bottom.
3. Change the default letter text in the surprise page if you like.
4. The recipient/sender names are entered on the welcome page.

PUBLISH FREE WITH GITHUB PAGES (ANDROID):
1. Sign in at https://github.com/ in Chrome.
2. Tap + (top right) > New repository.
3. Name it `love-test` and choose Public. Tap Create repository.
4. On the new repository page, tap Add file > Create new file.
5. Name the file exactly `index.html`.
6. Open the supplied index.html file in a text editor, copy all of it, paste it into GitHub's editor.
   On Android you can use a code editor app or open the file from your downloads and use Select all > Copy.
7. Scroll down and tap Commit changes.
8. Open repository Settings > Pages.
9. Under Build and deployment, choose Deploy from a branch.
10. Choose branch `main`, folder `/(root)`, then Save.
11. Wait a minute or two. Refresh Settings > Pages; GitHub will show your live link:
    https://YOUR-USERNAME.github.io/love-test/
12. Open the link in an incognito/private tab to test it, then send it to the person.

TIPS:
- Keep `index.html` at the repository root, not inside another folder.
- Repository must be Public for the straightforward free GitHub Pages setup.
- If you edit the site later, commit the changes; the live site updates after deployment.
- The score is a playful slider and isn't a real measure of anyone's feelings.
