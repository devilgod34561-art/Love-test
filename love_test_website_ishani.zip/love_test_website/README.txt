LOVE TEST WEBSITE — PERSONALIZED FOR AYUSH & ISHANI

Update your live site: open https://github.com/devilgod34561-art/Love-test, open index.html, tap Edit (pencil), replace the old code with this updated index.html, then Commit changes. Or use Add file > Upload files and upload this index.html, confirming replacement if prompted. Wait a few minutes and refresh your GitHub Pages link.

Score bands: 1–10% teddy; 11–30% chocolate; 31–60% flowers; 61–90% love note; 91–100% ring surprise. Each band has a different YouTube song search link.
